import React from 'react'
import {UncategorizedStudents} from "../../components/student-overview/studOverview.comp"

export const StudentOverview = () => {
    return (
        <div>
            <UncategorizedStudents/>
        </div>
    )
}
