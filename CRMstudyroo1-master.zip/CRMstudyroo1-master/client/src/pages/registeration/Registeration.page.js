  
import React from "react";

import {Signup} from "../../components/signup/Signup.comp";


export const Registration = () => {
  return (
    <div>
        <Signup/>
      
      </div>
  );
};