import React from 'react'
import {AddStudentForm} from "../../components/add-student-form/addStudentForm.comp"

export const NewStudent = () => {
    return (
        <div>
            <AddStudentForm/>
        </div>
    )
}
