import styled from '@emotion/styled';

export const App = styled.div`
  background: #ecf0f1;

  display: flex
`

export const Header = styled.h1`
  color: pink`